# Texture Valley 0.1

Texture Valley is a cross-platform procedural texture creator built with Python, Kivy, NumPy and Pillow.

## Included in 0.1
- Procedural Concrete, Wood, Metal and Wallpaper materials
- 256, 512, 1024 and 2048 square output sizes
- Scale, Noise and Detail controls
- Live 2D preview
- PNG export
- Responsive Kivy interface for desktop and touch devices

## Run on PC

Python 3.10–3.12 is recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
python main.py
```

## Build for Android

Android APK builds are normally done on Linux. Install Buildozer and its Android build dependencies, then from this folder run:

```bash
pip install buildozer
buildozer android debug
```

The first build downloads Android build tools and can take a while. The APK is created in `bin/`.

For a reliable Android build, use a Linux PC or a Linux environment supported by Buildozer. The app exports PNG files into its app data directory in `exports/`. A future version will add a system file picker / share sheet for easier access.

## Notes
- Version 0.1 uses procedural generation. AI generation is planned for a later version and is not represented as active in this build.
- Generated textures are square and intended as a first 2D texture workflow.
- Seamless tiling is an early approximation in 0.1; some material patterns may show a seam depending on settings.
